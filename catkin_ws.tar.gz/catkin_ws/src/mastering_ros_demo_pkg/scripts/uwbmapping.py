#!/usr/bin/env python
# Software License Agreement (BSD License)


import rospy
from std_msgs.msg import Float32
import serial
#a=0
#b=0
try:
    ser = serial.Serial('/dev/ttyUSB0', 57600)
except:
    print 'No Usb found !!'
global x
x=0
global y
y=0
global x1
global y1
x1 = float(raw_input("Enter x1: "))
y1 = float(raw_input("Enter y1: "))

def callback(data):

        #rospy.loginfo(rospy.get_caller_id() + 'x= %f', data.data)
	global x
        x= data.data
def callbacky(data1):
        #rospy.loginfo(rospy.get_caller_id() + 'y= %f', data1.data)
	global y
        y = data1.data
	print (x)
	print (y)
	if (x>0.200 and x<1.45) :
            ser.write('right')

def listener():

    
        
    rospy.init_node('listener', anonymous=True)
    rospy.Subscriber('coordinate_x', Float32, callback)
    rospy.Subscriber('coordinate_y', Float32, callbacky)




   
    

if __name__ == '__main__':
  try:

          
      listener()

      rospy.spin()
      
  except rospy.ROSInterruptException:
    ser.close()
    rospy.sleep(1)
    ser.open()
    pass
