#!/usr/bin/env python
# Software License Agreement (BSD License)


import rospy
from std_msgs.msg import Float32
import serial

ser = serial.Serial('/dev/ttyUSB0', 57600)


def callback(data,data1):
    rospy.loginfo(rospy.get_caller_id() + 'x= %f', data.data)
    ##print string(data)
    global x
    x=((data.data))
    print(x)
    if (x>0.200 and x<1.45) :
       ser.write('right')
##def callbacky(data):
   #rospy.loginfo(rospy.get_caller_id() + 'y= %f', data.data)
   #print data
    

def listener():
    
   
    rospy.init_node('listener', anonymous=True)

    rospy.Subscriber('coordinate_x', Float32, callback)
    rospy.Subscriber('coordinate_y', Float32, callbacky)

   
    rospy.spin()
if (x>0.200 and x<1.45) :
       ser.write('right')
if __name__ == '__main__':
  try:
      listener()
  except rospy.ROSInterruptException:
    ser.close()
    rospy.sleep(1)
    ser.open()
    pass
